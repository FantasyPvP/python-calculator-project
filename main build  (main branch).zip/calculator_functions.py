import math


def process(instruction_list, bracket, a, b, operation_count):
    sqrt_count_brackets = bracket.count("sqrt")

    # sqrt module
    
    for i in range(sqrt_count_brackets):
        x = instruction_list.index("sqrt", a, b)
        instruction_list[x] = math.sqrt(float(instruction_list[x + 1]))
        instruction_list.pop(x + 1)
        operation_count = operation_count + 1
        print(instruction_list)

    # powers module

    power_count_brackets = bracket.count("**")

    for i in range(power_count_brackets):
        x = instruction_list.index("**", a, b)
        instruction_list[x] = float(instruction_list[x - 1]) ** float(instruction_list[x + 1])
        instruction_list.pop(x + 1)
        instruction_list.pop(x - 1)
        operation_count = operation_count + 2
        print(instruction_list)

    # sine module (trigonometric)

    power_count_sin = bracket.count("sin")

    for i in range(power_count_sin):
        x = instruction_list.index("sin", a, b)
        instruction_list[x] = math.sin(float(instruction_list[x + 1]))
        instruction_list.pop(x + 1)
        operation_count = operation_count + 1
        print(instruction_list)

    # cosine module (trigonometric )

    power_count_cos = bracket.count("cos")

    for i in range(power_count_cos):
        x = instruction_list.index("cos", a, b)
        instruction_list[x] = math.cos(float(instruction_list[x + 1]))
        instruction_list.pop(x + 1)
        operation_count = operation_count + 1
        print(instruction_list)

    # tangent module (trigonometric)

    power_count_tan = bracket.count("tan")

    for i in range(power_count_tan):
        x = instruction_list.index("tan", a, b)
        instruction_list[x] = math.tan(float(instruction_list[x + 1]))
        instruction_list.pop(x + 1)
        operation_count = operation_count + 1
        print(instruction_list)

    # multiplication module

    multiplication_count_brackets = bracket.count("*")

    for i in range(multiplication_count_brackets):
        x = instruction_list.index("*", a, b)
        instruction_list[x] = float(instruction_list[x - 1]) * float(instruction_list[x + 1])
        instruction_list.pop(x + 1)
        instruction_list.pop(x - 1)
        operation_count = operation_count + 2
        print(instruction_list)

    # remainder division module

    remainder_div_count_brackets = bracket.count("%")

    for i in range(remainder_div_count_brackets):
        x = instruction_list.index("%", a, b)
        instruction_list[x] = float(instruction_list[x - 1]) % float(instruction_list[x + 1])
        instruction_list.pop(x + 1)
        instruction_list.pop(x - 1)
        operation_count = operation_count + 2
        print(instruction_list)

    # integer division module

    int_div_count_brackets = bracket.count("//")

    for i in range(int_div_count_brackets):
        x = instruction_list.index("//", a, b)
        instruction_list[x] = float(instruction_list[x - 1]) // float(instruction_list[x + 1])
        instruction_list.pop(x + 1)
        instruction_list.pop(x - 1)
        operation_count = operation_count + 2
        print(instruction_list)

    # division module

    div_count_brackets = bracket.count("/")

    for i in range(div_count_brackets):
        x = instruction_list.index("/", a, b)
        instruction_list[x] = float(instruction_list[x - 1]) / float(instruction_list[x + 1])
        instruction_list.pop(x + 1)
        instruction_list.pop(x - 1)
        operation_count = operation_count + 2
        print(instruction_list)

    # addition module

    addition_count_brackets = bracket.count("+")

    for i in range(addition_count_brackets):
        x = instruction_list.index("+", a, b)
        instruction_list[x] = float(instruction_list[x - 1]) + float(instruction_list[x + 1])
        instruction_list.pop(x + 1)
        instruction_list.pop(x - 1)
        operation_count = operation_count + 2
        print(instruction_list)

    # subtraction module

    subtraction_count_brackets = bracket.count("-")

    for i in range(subtraction_count_brackets):
        x = instruction_list.index("-", a, b)
        instruction_list[x] = float(instruction_list[x - 1]) - float(instruction_list[x + 1])
        instruction_list.pop(x + 1)
        instruction_list.pop(x - 1)
        operation_count = operation_count + 2
        print(instruction_list)

    return instruction_list
    return instruction_count
