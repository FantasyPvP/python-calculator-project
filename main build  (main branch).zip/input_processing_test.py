import logic_and_BIDMAS as bidmas


def process_input(equation):
    total_length = len(equation)
    print("""
          next equation:
    """,equation)
    # moving each character of the equation to a separate variable in a list (instruction_list_unprocessed)

    instruction_list_unprocessed = []
    instruction_list = []
    
    for i in range(total_length):
        instruction_list_unprocessed.append(equation[i])
    instruction_list_unprocessed.append("x")
    # consolidating multi digit numbers

    for i in range(total_length):
        if str(instruction_list_unprocessed[i]).isnumeric():
            if str(instruction_list_unprocessed[i + 1]).isnumeric():
                instruction_list_unprocessed[i + 1] = instruction_list_unprocessed[i] + instruction_list_unprocessed[i + 1]
                instruction_list_unprocessed[i] = "empty"

    # consolidating muliti character operators

    for i in range(total_length):
        if str(instruction_list_unprocessed[i]).isnumeric():
            b = 0
        else:
            if instruction_list_unprocessed[i] == instruction_list_unprocessed[i + 1]:
                instruction_list_unprocessed[i + 1] = instruction_list_unprocessed[i] + instruction_list_unprocessed[i + 1]
                instruction_list_unprocessed[i] = "empty"

    # consolidating sqrt command

    for i in range(total_length):
        if str(instruction_list_unprocessed[i]).isalpha():
            if str(instruction_list_unprocessed[i]) == "s":
                if str(instruction_list_unprocessed[i + 1]) == "q":
                    if str(instruction_list_unprocessed[i + 2]) == "r":
                        if str(instruction_list_unprocessed[i + 3]) == "t":
                            instruction_list.append("sqrt")
                        else: instruction_list.append(instruction_list_unprocessed[i])

        if str(instruction_list_unprocessed[i]).isalpha():
            if str(instruction_list_unprocessed[i]) == "s":
                if str(instruction_list_unprocessed[i + 1]) == "i":
                    if str(instruction_list_unprocessed[i + 2]) == "n":
                        instruction_list.append("sin")
                    else: instruction_list.append(instruction_list_unprocessed[i])

        if str(instruction_list_unprocessed[i]).isalpha():
            if str(instruction_list_unprocessed[i]) == "c":
                if str(instruction_list_unprocessed[i + 1]) == "o":
                    if str(instruction_list_unprocessed[i + 2]) == "s":
                        instruction_list.append("cos")
                    else: instruction_list.append(instruction_list_unprocessed[i])

        if str(instruction_list_unprocessed[i]).isalpha():
            if str(instruction_list_unprocessed[i]) == "t":
                if str(instruction_list_unprocessed[i + 1]) == "a":
                    if str(instruction_list_unprocessed[i + 2]) == "n":
                        instruction_list.append("tan")
                    else: instruction_list.append(instruction_list_unprocessed[i])
        else:
            instruction_list.append(instruction_list_unprocessed[i])
    if instruction_list[-1] == "\n":
        instruction_list.pop()
    return(instruction_list)


