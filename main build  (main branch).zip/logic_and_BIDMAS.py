import calculator_functions as calculate


instruction_list = ['1', '+', '2', '+', 'cos', '3', '**', '4', '*', 'sqrt', '5']


def process_calculation(instruction_list):
    operation_count = 0
    length = len(instruction_list)
    operation_count = 0
    brackets = instruction_list.count("(")
    print("            solving...")

    for i in range(brackets):
        a = int(instruction_list.index("("))
        b = int(instruction_list.index(")"))
        bracket = instruction_list[a:b]
        instruction_list = calculate.process(instruction_list, bracket, a, b, operation_count)
        instruction_list.remove("(")
        instruction_list.remove(")")

    a = 0
    b = len(instruction_list) - 1
    bracket = instruction_list[a:b]
    instruction_list = calculate.process(instruction_list, bracket, a, b, operation_count)
    answer = instruction_list
    return(answer)

