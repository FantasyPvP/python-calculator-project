import tkinter as tk
import input_processing_test as start
import logic_and_BIDMAS as bidmas
import math
height_set = 360
width_set = 480

def input_command():
    equation = (equation_input.get())
    intruction_list = start.process_input(equation)
    answer = bidmas.process_calculation(instruction_list)

def file_command():
    file_name = (equation_input.get())
    equation_file = open(r"equations.txt", "r")
    for equation in equation_file:
        instruction_list = start.process_input(equation)
        answer = bidmas.process_calculation(instruction_list)
        output_command(answer)
        print("your final answer is:", answer)

def output_command(answer):
    equation_output = tk.Label(lower_frame, bg = "gray", fg = "white", width = "50", text = answer)
    equation_output.pack(side = "top", fill = "both")

root = tk.Tk()

root.title("calculator")
root.iconbitmap("app_icon.ico")
root.geometry("400x600")



canvas = tk.Canvas(root, height = height_set, width = width_set)
canvas.pack()


background_image = tk.PhotoImage(file = "background_image.png")
background_label = tk.Label(root, image = background_image)
background_label.place(x = 0, y = 0, relwidth = 1, relheight = 1)

top_image = tk.Frame(root, bg = "#2e2e2e")
top_image.place(relx = 0.08, rely = 0.08, relwidth = 0.84, relheight = 0.24)

lower_image = tk.Frame(root, bg = "#2e2e2e")
lower_image.place(relx = 0.08, rely = 0.38, relwidth = 0.84, relheight = 0.54)


top_frame = tk.Frame(root, bg = "#8a8a8a")
top_frame.place(relx = 0.1, rely = 0.1, relwidth = 0.8, relheight = 0.2)

lower_frame = tk.Frame(root, bg = "#8a8a8a")
lower_frame.place(relx = 0.1, rely = 0.4, relwidth = 0.8, relheight = 0.5)



equation_input = tk.Entry(top_frame, bg = "gray", fg = "white", width = "50")
equation_input.pack(side = "top", fill = "both")


equation_submit = tk.Button(top_frame, bg = "gray", fg = "white", width = "50", text = "calculate", command = input_command)
equation_submit.pack(side = "top", fill = "both")

equation_file_submit = tk.Button(top_frame, bg = "gray", fg = "white", width = "50", text = "calculate from file (enter file above)", command = file_command)
equation_file_submit.pack(side = "top", fill = "both")

equation_output = tk.Entry(lower_frame, bg = "gray", fg = "white", width = "50")
equation_output.pack(side = "top", fill = "both")

root.mainloop()
